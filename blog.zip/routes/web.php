<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\Controller;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CommentController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/categories', [CategoryController::class,'index'])->name('category.index');
Route::get('/categories{id}', [CategoryController::class,'show'])->name('category.show');
Route::get('/', [PostController::class,'index'])->name('post.index');

Route::get('post.dep', [PostController::class,'dep'])->name('post.dep');
Route::get('post.uh', [PostController::class,'uh'])->name('post.uh');
Route::get('post.rec', [PostController::class,'rec'])->name('post.rec');

Route::get('category.rec1', [CategoryController::class,'rec1'])->name('category.rec1');
Route::get('category.rec2', [CategoryController::class,'rec2'])->name('category.rec2');
Route::get('category.rec3', [CategoryController::class,'rec3'])->name('category.rec3');

Route::get('category.UH1', [CategoryController::class,'UH1'])->name('category.UH1');
Route::get('category.UH2', [CategoryController::class,'UH2'])->name('category.UH2');
Route::get('category.UH3', [CategoryController::class,'UH3'])->name('category.UH3');

Route::get('category.dep1', [CategoryController::class,'dep1'])->name('category.dep1');
Route::get('category.dep2', [CategoryController::class,'dep2'])->name('category.dep2');
Route::get('category.dep3', [CategoryController::class,'dep3'])->name('category.dep3');

Route::post('/comments', [CommentController::class,'store'])->name('comment.create');

