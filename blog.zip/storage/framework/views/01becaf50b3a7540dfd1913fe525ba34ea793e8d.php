

<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <p><a href="<?php echo e(route('post.show',['id'=>$post->id])); ?>">
                <?php echo e($post->title); ?>

            </a>
        </p>
        <p><?php echo e($post->user->name); ?></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Xampp\htdocs\bloglaravel8\resources\views/post/index.blade.php ENDPATH**/ ?>