<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Cómo hacer la tarta de queso «La Viña». La auténtica receta donostiarra</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.4/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.html">Home</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="about.html">About</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="post.html">Sample Post</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="contact.html">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Page Header-->
        <header class="masthead" style="background-image: url('assets/img/rac3.png')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="post-heading">
                            <h1>Cómo hacer la tarta de queso «La Viña». La auténtica receta donostiarra</h1>
                       </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Post Content-->
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                    <!-- Post preview-->
                    <div class="post-preview">
                        
 <H3>Ingredientes</H3><br>
            <br>
1 kg.. de vuestro queso crema preferido (crema de queso tipo Philadelphia)<br>
5 huevos camperos<br>
300 g. de azúcar<br>
500 ml. de nata líquida o crema de leche para montar (mínimo 35% de grasa)<br>
1 cucharada de harina de trigo ( unos 15 g. aprox.) También vale almidón de maíz o Maicena si eres celíaco<br>
1 pizca de sal (5 g.)<br>
Un molde de 24 cm. de diámetro<br>
2 hojas de papel de horno<br>
<br>
Prueba también: Tarta de queso al horno · Tarta de queso fría · Tarta de queso philadelphia · Tarta de queso sin horno · Tarta de queso fácil · Tarta con crema de queso · Tarta de queso japonesa
<br>
                        <br>
Atención amantes de la tarta de queso porque el postre de hoy os va a encantar. Se trata de la tarta La Viña, el dulce más popular del bar restaurante «La Viña» de la parte vieja donostiarra y archiconocida entre los amantes del buen comer y la gastronomía.
<br>
                        <br>
Existen montones de recetas de tartas de queso, pero no todas han sido elegidas como uno de los mejores sabores del año por el New York Times. Hablamos de la tarta de queso del restaurante La Viña, que se encuentra en el casco antiguo de San Sebastián y donde llevan sirviendo esta tarta desde hace 28 años. Por suerte la receta no es ningún secreto y ahora podemos prepararla en casa cada vez que nos apetezca.
<br>
                        <br>
Es una tarta muy sencilla, solo tenemos que mezclar 5 ingredientes en un bol y hornear sin prisa. El resultado es tan espectacular que cuesta creer que sea tan fácil de preparar. Si queremos lucirnos un día especial, es la opción perfecta sobre todo para los amantes de las cheesecakes.


                               
                        <br>
                        <br>
                    </div>
                   
                </div>
            </div>
        </div>
        <!-- Footer-->
        <footer class="border-top">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <ul class="list-inline text-center">
                            <li class="list-inline-item">
                                <a href="#!">
                                    <span class="fa-stack fa-lg">
                                        <i class="fas fa-circle fa-stack-2x"></i>
                                        <i class="fab fa-twitter fa-stack-1x fa-inverse"></i>
                                    </span>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#!">
                                    <span class="fa-stack fa-lg">
                                        <i class="fas fa-circle fa-stack-2x"></i>
                                        <i class="fab fa-facebook-f fa-stack-1x fa-inverse"></i>
                                    </span>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#!">
                                    <span class="fa-stack fa-lg">
                                        <i class="fas fa-circle fa-stack-2x"></i>
                                        <i class="fab fa-github fa-stack-1x fa-inverse"></i>
                                    </span>
                                </a>
                            </li>
                        </ul>
                        <div class="small text-center text-muted fst-italic">Copyright &copy; Your Website 2021</div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>




<?php /**PATH E:\bloglaravel8\resources\views/category/rec1.blade.php ENDPATH**/ ?>