

<h1><?php echo e($post->title); ?></h1>
<div>By: <?php echo e($post->user->name); ?></div>
<div><?php echo e($post->content); ?></div>

<div>
<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>
        <b><?php echo e($comment->user->name); ?></b>
        <?php echo e($comment->comment); ?>

    </p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<form action="" method="post">
    
    <input type="hidden" name="user_id" value="1">
    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
    <label for="lcomment">Comment</label><br>
    <textarea id="lcomment" name="textarea" rows="10">Write here</textarea>
    <input type="submit" name="Submit">

</form><?php /**PATH C:\Xampp\htdocs\bloglaravel8\resources\views/post/show.blade.php ENDPATH**/ ?>