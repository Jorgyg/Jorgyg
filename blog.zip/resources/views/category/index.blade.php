
<h1>Categories</h1>

@foreach ($categories as $category)
    <p><a href="{{route('category.show',['id'=>$category->id])}}">{{ $category->title }}</a></p>
@endforeach