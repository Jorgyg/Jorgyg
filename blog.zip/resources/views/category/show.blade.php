
<h1>Category: {{$category->title}}</h1>

@foreach ($category->posts as $post)
    <p><a href="{{route('post.show',$post->id)}}">{{ $post->title }}</a></p>
@endforeach